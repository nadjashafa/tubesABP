<?php $__env->startSection('testaja'); ?>
<h1>HAI NADJA BISA NIH!</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('login.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nadjashafa/Documents/nad_sekolah/PRAKTIKUM/PRAKTIKUM_ABP/tubesABP/resources/views/regist.blade.php ENDPATH**/ ?>